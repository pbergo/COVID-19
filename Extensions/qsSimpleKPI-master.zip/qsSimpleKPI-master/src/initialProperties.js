export default {
  version : 1.4,
  qHyperCubeDef: {
    qDimensions: [],
    qMeasures: [],
    qInitialDataFetch: [{
      qWidth: 125,
      qHeight: 80
    }]
  },
  options: {}
}
